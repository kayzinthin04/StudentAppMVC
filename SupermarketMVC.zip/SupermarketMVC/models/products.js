const db = require('../db');

const ProductModel = {
  // Get all products
  getAll(callback) {
    const sql = 'SELECT productId, name, quantity, price, image FROM products';
    db.query(sql, (err, results) => {
      if (err) return callback(err);
      return callback(null, results);
    });
  },

  // Get product by ID
  getById(id, callback) {
    const sql = 'SELECT productId, name, quantity, price, image FROM products WHERE productId = ?';
    db.query(sql, [id], (err, results) => {
      if (err) return callback(err);
      const row = Array.isArray(results) && results.length ? results[0] : null;
      return callback(null, row);
    });
  },

  // Add a new product
  // product: { name, quantity, price, image }
  add(product, callback) {
    const sql = 'INSERT INTO products (name, quantity, price, image) VALUES (?, ?, ?, ?)';
    const params = [
      product.name ?? null,
      product.quantity ?? null,
      product.price ?? null,
      product.image ?? null
    ];
    db.query(sql, params, (err, result) => {
      if (err) return callback(err);
      return callback(null, { insertId: result.insertId, affectedRows: result.affectedRows });
    });
  },

  // Update existing product by id
  // product: { name, quantity, price, image }
  update(id, product, callback) {
    const sql = 'UPDATE products SET name = ?, quantity = ?, price = ?, image = ? WHERE productId = ?';
    const params = [
      product.name ?? null,
      product.quantity ?? null,
      product.price ?? null,
      product.image ?? null,
      id
    ];
    db.query(sql, params, (err, result) => {
      if (err) return callback(err);
      return callback(null, { affectedRows: result.affectedRows, changedRows: result.changedRows });
    });
  },

  // Delete product by id
  delete(id, callback) {
    const sql = 'DELETE FROM products WHERE productId = ?';
    db.query(sql, [id], (err, result) => {
      if (err) return callback(err);
      return callback(null, { affectedRows: result.affectedRows });
    });
  }
};

module.exports = ProductModel;