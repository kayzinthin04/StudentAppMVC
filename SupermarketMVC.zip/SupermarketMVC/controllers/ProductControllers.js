const Product = require('../models/products');

const ProductController = {
  // List all products -> renders index.ejs (adjust view name if you want inventory/admin view)
  list(req, res) {
    Product.getAll((err, products) => {
      if (err) {
        console.error(err);
        return res.status(500).render('index', { products: [], error: 'Database error' });
      }
      res.render('index', { products, error: null });
    });
  },

  // Show one product -> renders product.ejs
  show(req, res) {
    const id = req.params.id || req.params.productId;
    if (!id) return res.status(400).send('Missing product ID');

    Product.getById(id, (err, product) => {
      if (err) {
        console.error(err);
        return res.status(500).render('product', { product: null, error: 'Database error' });
      }
      if (!product) return res.status(404).render('product', { product: null, error: 'Product not found' });
      res.render('product', { product, error: null });
    });
  },

  // Render add product form (optional helper)
  addForm(req, res) {
    res.render('addProduct', { product: null, error: null });
  },

  // Add a new product -> handles form data and optional file uploads
  create(req, res) {
    // pick uploaded file from multer shapes (single/fields/any)
    const uploaded = req.file ?? (
      req.files && (req.files.image?.[0] || req.files.imageFile?.[0] || req.files[Object.keys(req.files)[0]]?.[0])
    );

    const product = {
      name: req.body.name || null,
      quantity: req.body.quantity ?? null,
      price: req.body.price ?? null,
      image: uploaded ? uploaded.filename : (req.body.image || null)
    };

    Product.add(product, (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).render('addProduct', { product, error: 'Failed to add product' });
      }
      res.redirect('/');
    });
  },

  // Render edit form for a product
  edit(req, res) {
    const id = req.params.id || req.params.productId;
    if (!id) return res.status(400).send('Missing product ID');

    Product.getById(id, (err, product) => {
      if (err) {
        console.error(err);
        return res.status(500).render('editProduct', { product: null, error: 'Database error' });
      }
      if (!product) return res.status(404).render('editProduct', { product: null, error: 'Product not found' });
      res.render('editProduct', { product, error: null });
    });
  },

  // Update an existing product -> handles file uploads and form data
  update(req, res) {
    const id = req.params.id || req.params.productId;
    if (!id) return res.status(400).send('Missing product ID');

    const uploaded = req.file ?? (
      req.files && (req.files.image?.[0] || req.files.imageFile?.[0] || req.files[Object.keys(req.files)[0]]?.[0])
    );

    const product = {
      name: req.body.name || null,
      quantity: req.body.quantity ?? null,
      price: req.body.price ?? null,
      image: uploaded ? uploaded.filename : (req.body.image || null)
    };

    Product.update(id, product, (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).render('editProduct', { product: { productId: id, ...product }, error: 'Failed to update product' });
      }
      res.redirect('/');
    });
  },

  // Delete a product -> redirects to list
  remove(req, res) {
    const id = req.params.id || req.params.productId;
    if (!id) return res.status(400).send('Missing product ID');

    Product.delete(id, (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Failed to delete product');
      }
      res.redirect('/');
    });
  }
};

module.exports = ProductController;