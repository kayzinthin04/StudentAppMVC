// ...existing code...
const Student = require('../models/Student');

const MAX_CONTACT_LENGTH = 20; // adjust to match/ exceed your DB column length (VARCHAR recommended)

const StudentController = {
    // List all students -> renders index.ejs with students
    list(req, res) {
        Student.getAll((err, students) => {
            if (err) {
                console.error(err);
                return res.status(500).render('index', { students: [], error: 'Database error' });
            }
            res.render('index', { students, error: null });
        });
    },

    // Show one student -> renders student.ejs
    show(req, res) {
        const id = req.params.id || req.params.studentId;
        if (!id) return res.status(400).send('Missing student ID');

        Student.getById(id, (err, student) => {
            if (err) {
                console.error(err);
                return res.status(500).render('student', { student: null, error: 'Database error' });
            }
            if (!student) return res.status(404).render('student', { student: null, error: 'Student not found' });
            res.render('student', { student, error: null });
        });
    },

    // Render edit form for a student -> renders editStudent.ejs
    edit(req, res) {
        const id = req.params.id || req.params.studentId;
        if (!id) return res.status(400).send('Missing student ID');

        Student.getById(id, (err, student) => {
            if (err) {
                console.error(err);
                return res.status(500).render('editStudent', { student: null, error: 'Database error' });
            }
            if (!student) return res.status(404).render('editStudent', { student: null, error: 'Student not found' });
            res.render('editStudent', { student, error: null });
        });
    },

    // Add a new student -> expects form data in req.body and optional file in req.file/req.files
    create(req, res) {
        const contactRaw = (req.body.contact || '').toString().trim();
        if (contactRaw.length > MAX_CONTACT_LENGTH) {
            return res.status(400).render('addStudent', {
                student: { name: req.body.name, dob: req.body.dob, contact: contactRaw, image: req.body.image },
                error: `Contact too long (max ${MAX_CONTACT_LENGTH} chars)`
            });
        }

        // find uploaded file (support req.file or upload.fields -> req.files)
        const uploaded = req.file ?? (
            req.files && (req.files.image?.[0] || req.files.imageFile?.[0] || req.files[Object.keys(req.files)[0]]?.[0])
        );

        const student = {
            name: req.body.name,
            dob: req.body.dob,
            contact: contactRaw,
            image: uploaded ? uploaded.filename : (req.body.image || null)
        };

        Student.add(student, (err, result) => {
            if (err) {
                console.error(err);
                return res.status(500).render('addStudent', { student, error: 'Failed to add student' });
            }
            res.redirect('/');
        });
    },

    // Update an existing student -> expects id in params and updated fields in req.body / req.file/req.files
    update(req, res) {
        const id = req.params.id || req.params.studentId;
        if (!id) return res.status(400).send('Missing student ID');

        const contactRaw = (req.body.contact || '').toString().trim();
        if (contactRaw.length > MAX_CONTACT_LENGTH) {
            return res.status(400).render('editStudent', {
                student: { studentId: id, name: req.body.name, dob: req.body.dob, contact: contactRaw, image: req.body.image },
                error: `Contact too long (max ${MAX_CONTACT_LENGTH} chars)`
            });
        }

        // find uploaded file (support req.file or upload.fields -> req.files)
        const uploaded = req.file ?? (
            req.files && (req.files.image?.[0] || req.files.imageFile?.[0] || req.files[Object.keys(req.files)[0]]?.[0])
        );

        const student = {
            name: req.body.name,
            dob: req.body.dob,
            contact: contactRaw,
            image: uploaded ? uploaded.filename : (req.body.image || null)
        };

        Student.update(id, student, (err, result) => {
            if (err) {
                console.error(err);
                return res.status(500).render('editStudent', { student: { studentId: id, ...student }, error: 'Failed to update student' });
            }
            // go back to the list where updated data will be visible
            res.redirect('/');
        });
    },

    // Delete a student -> expects id in params
    remove(req, res) {
        const id = req.params.id || req.params.studentId;
        if (!id) return res.status(400).send('Missing student ID');

        Student.delete(id, (err, result) => {
            if (err) {
                console.error(err);
                return res.status(500).send('Failed to delete student');
            }
            res.redirect('/');
        });
    }
};

module.exports = StudentController;
// ...existing code...