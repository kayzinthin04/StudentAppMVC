const db = require('../db');

const StudentModel = {
    // Get all students
    getAll(cb) {
        const sql = 'SELECT studentId, name, dob, contact, image FROM students';
        db.query(sql, (err, results) => cb(err, results));
    },

    // Get a student by ID
    getById(studentId, cb) {
        const sql = 'SELECT studentId, name, dob, contact, image FROM students WHERE studentId = ?';
        db.query(sql, [studentId], (err, results) => {
            if (err) return cb(err);
            cb(null, results[0] || null);
        });
    },

    // Add a new student (student = { name, dob, contact, image })
    add(student, cb) {
        const sql = 'INSERT INTO students (name, dob, contact, image) VALUES (?, ?, ?, ?)';
        const params = [student.name, student.dob, student.contact, student.image];
        db.query(sql, params, (err, result) => cb(err, result));
    },

    // Update an existing student by ID (student = { name, dob, contact, image })
    update(studentId, student, cb) {
        const sql = 'UPDATE students SET name = ?, dob = ?, contact = ?, image = ? WHERE studentId = ?';
        const params = [student.name, student.dob, student.contact, student.image, studentId];
        db.query(sql, params, (err, result) => cb(err, result));
    },

    // Delete a student by ID
    delete(studentId, cb) {
        const sql = 'DELETE FROM students WHERE studentId = ?';
        db.query(sql, [studentId], (err, result) => cb(err, result));
    }
};

module.exports = StudentModel;