const express = require('express');
const multer = require('multer');
const app = express();

// import the student controller (per instructions)
const studentController = require('./controllers/studentControllers');

// Set up multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/images'); // Directory to save uploaded files
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    }
});

const upload = multer({ storage: storage });

// Accept either "image" or "imageFile" (both optional, max 1 file each)
const uploadEither = upload.fields([
    { name: 'image', maxCount: 1 },
    { name: 'imageFile', maxCount: 1 }
]);

// Set up view engine
app.set('view engine', 'ejs');
//  enable static files
app.use(express.static('public'));
// enable form processing
app.use(express.urlencoded({
    extended: false
}));

// Routes — delegate all DB work to controller methods

// list all students
app.get('/', (req, res) => {
    studentController.list(req, res);
});

// show single student
app.get('/student/:id', (req, res) => {
    studentController.show(req, res);
});

// render add student form
app.get('/addStudent', (req, res) => {
    res.render('addStudent');
});

// handle add student (with file upload)
app.post('/addStudent', uploadEither, (req, res) => {
    studentController.create(req, res);
});

// render edit student form (controller should provide the data and render)
// NOTE: controller.show may render a different view; ensure your controller handles edit route rendering.
// If your controller exposes a dedicated method for rendering the edit form, change this to call that method.
app.get('/editStudent/:id', (req, res) => {
    // try to delegate to controller; controller should render the appropriate edit view
    if (typeof studentController.edit === 'function') {
        studentController.edit(req, res);
    } else {
        // fallback to show — your controller can inspect the route and render edit view if implemented
        studentController.show(req, res);
    }
});

// handle update student (with file upload)
app.post('/editStudent/:id', uploadEither, (req, res) => {
    studentController.update(req, res);
});

// delete student
app.get('/deleteStudent/:id', (req, res) => {
    studentController.remove(req, res);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
